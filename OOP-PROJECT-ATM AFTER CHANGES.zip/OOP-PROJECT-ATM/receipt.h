#ifndef RECEIPT_H_INCLUDED
#define RECEIPT_H_INCLUDED

#include <iostream>
#include <time.h>
using namespace std;

void printing()
{
    border();
    gotoxy(43,12);
    cout<<".....PLEASE WAIT.....";
    gotoxy(40,14);
    cout<<"PRINTING......";
    gotoxy(40,16);
    cout<<"0                    100";
    gotoxy(41,16);
    for(int i=0;i<20;i++)
    {
        cout<<"#";
        Sleep(200);
    }

    gotoxy(40,18);
    cout<<"....PRINT SUCCESSFUL....";
    gotoxy(37,20);
    cout<<"PRESS ANY KEY TO RETURN TO MAIN MENU...";
    cin.get();
}

void printReceipt(const Accountholder acc,float amount,int x)
{
    border();
    gotoxy(45,4);
    cout<<"STATE BANK OF INDIA";
    gotoxy(20,5);
    time_t ttime = time(0);
    char *dt = ctime(&ttime);
    cout<<"Date and Time : ";
    gotoxy(65,5);
    cout<<"ATM ID";
    gotoxy(20,6);
    cout<<dt;
    gotoxy(65,6);
    cout<<"E006773";
    gotoxy(20,8);
    cout<<"CARD NUMBER ";
    gotoxy(65,8);
    cout<<"XXXX XXXX XXXX 6513";
    srand(time(nullptr));
    int txn_no = rand()%8999 + 1000;
    gotoxy(20,10);
    cout<<"TXN NO.";
    gotoxy(65,10);
    cout<<txn_no;
    gotoxy(20,12);
    cout<<"RESPONSE CODE";
    gotoxy(65,12);
    cout<<"000";
    gotoxy(20,14);
    cout<<(x==0?"WITHDRAWL":"DEPOSIT");
    gotoxy(60,14);
    cout<<"RS.";
    gotoxy(65,14);
    cout<<amount;
    gotoxy(20,16);
    cout<<"FROM A/C";
    gotoxy(65,16);
    cout<<acc.account_no;
    gotoxy(20,18);
    cout<<"MOD BAL";
    gotoxy(60,18);
    cout<<"RS.";
    gotoxy(65,18);
    cout<<"0.00";
    gotoxy(20,20);
    cout<<"AVAIL BAL";
    gotoxy(60,20);
    cout<<"RS.";
    gotoxy(65,20);
    cout<<acc.balance;
    gotoxy(40,22);
    cout<<"Visit us at www.sbi.co.in";

    gotoxy(40,25);
    cout<<"PRESS ANY KEY TO START PRINTING...";
    cin.get();
    printing();
}



#endif // RECEIPT_H_INCLUDED
